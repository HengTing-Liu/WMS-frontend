import{a2 as e,ao as n,ay as o}from"../jse/index-index-N7mfrkHY.js";const l=e({__name:"inbound-modal",setup(a){return(t,r)=>(n(),o("div",null,"inbound-modal.vue"))}});export{l as default};
