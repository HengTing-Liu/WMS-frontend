import{a2 as e,ao as o,ay as a}from"../jse/index-index-N7mfrkHY.js";const l=e({__name:"count-modal",setup(n){return(t,c)=>(o(),a("div",null,"count-modal.vue"))}});export{l as default};
