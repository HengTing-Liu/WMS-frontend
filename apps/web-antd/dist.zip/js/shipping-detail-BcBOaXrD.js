import{a2 as e,ao as a,ay as n}from"../jse/index-index-N7mfrkHY.js";const s=e({__name:"shipping-detail",setup(t){return(o,p)=>(a(),n("div",null,"shipping-detail.vue"))}});export{s as default};
