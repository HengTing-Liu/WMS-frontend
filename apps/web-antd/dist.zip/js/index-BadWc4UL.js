import{C as s,A as t}from"./Col-B-RSPi81.js";import{p as o}from"./bootstrap-BrzYYM59.js";const l=o(s),m=o(t);export{l as C,m as R};
