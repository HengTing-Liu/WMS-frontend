import{a2 as e,ao as a,ay as t}from"../jse/index-index-N7mfrkHY.js";const p=e({__name:"express-detail",setup(s){return(n,o)=>(a(),t("div",null,"express-detail.vue"))}});export{p as default};
