import{a2 as e,ao as a,ay as n}from"../jse/index-index-N7mfrkHY.js";const c=e({__name:"sign-detail",setup(t){return(o,s)=>(a(),n("div",null,"sign-detail.vue"))}});export{c as default};
