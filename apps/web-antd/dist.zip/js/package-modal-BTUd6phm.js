import{a2 as a,ao as e,ay as o}from"../jse/index-index-N7mfrkHY.js";const r=a({__name:"package-modal",setup(n){return(t,c)=>(e(),o("div",null,"package-modal.vue"))}});export{r as default};
