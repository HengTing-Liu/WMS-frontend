import{a9 as s,ay as t}from"./bootstrap-BrzYYM59.js";var a="[object Symbol]";function e(o){return typeof o=="symbol"||s(o)&&t(o)==a}export{e as i};
