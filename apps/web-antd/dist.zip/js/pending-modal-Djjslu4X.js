import{a2 as e,ao as n,ay as a}from"../jse/index-index-N7mfrkHY.js";const c=e({__name:"pending-modal",setup(o){return(t,p)=>(n(),a("div",null,"pending-modal.vue"))}});export{c as default};
