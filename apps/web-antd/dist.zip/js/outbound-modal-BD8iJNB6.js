import{a2 as o,ao as e,ay as a}from"../jse/index-index-N7mfrkHY.js";const c=o({__name:"outbound-modal",setup(n){return(t,u)=>(e(),a("div",null,"outbound-modal.vue"))}});export{c as default};
