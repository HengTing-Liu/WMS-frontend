import{a2 as a,ao as e,ay as t}from"../jse/index-index-N7mfrkHY.js";const d=a({__name:"standard-detail",setup(n){return(o,r)=>(e(),t("div",null,"standard-detail.vue"))}});export{d as default};
