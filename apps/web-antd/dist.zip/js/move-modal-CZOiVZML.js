import{a2 as e,ao as o,ay as a}from"../jse/index-index-N7mfrkHY.js";const c=e({__name:"move-modal",setup(n){return(t,m)=>(o(),a("div",null,"move-modal.vue"))}});export{c as default};
