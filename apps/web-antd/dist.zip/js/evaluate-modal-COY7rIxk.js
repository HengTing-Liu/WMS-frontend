import{a2 as e,ao as a,ay as o}from"../jse/index-index-N7mfrkHY.js";const c=e({__name:"evaluate-modal",setup(t){return(n,l)=>(a(),o("div",null,"evaluate-modal.vue"))}});export{c as default};
