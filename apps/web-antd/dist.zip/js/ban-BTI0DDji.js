import{b6 as c}from"./bootstrap-BrzYYM59.js";const e=c("ban",[["path",{d:"M4.929 4.929 19.07 19.071",key:"196cmz"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);export{e as B};
