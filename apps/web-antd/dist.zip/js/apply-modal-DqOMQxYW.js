import{a2 as a,ao as e,ay as o}from"../jse/index-index-N7mfrkHY.js";const r=a({__name:"apply-modal",setup(n){return(p,t)=>(e(),o("div",null,"apply-modal.vue"))}});export{r as default};
