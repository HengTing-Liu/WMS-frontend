import{a2 as e,ao as o,ay as t}from"../jse/index-index-N7mfrkHY.js";const l=e({__name:"outorder-detail",setup(a){return(r,n)=>(o(),t("div",null,"outorder-detail.vue"))}});export{l as default};
