import{a2 as e,ao as a,ay as o}from"../jse/index-index-N7mfrkHY.js";const l=e({__name:"dict-modal",setup(t){return(n,c)=>(a(),o("div",null,"dict-modal.vue"))}});export{l as default};
