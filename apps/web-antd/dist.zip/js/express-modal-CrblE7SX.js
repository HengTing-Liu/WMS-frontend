import{a2 as e,ao as a,ay as o}from"../jse/index-index-N7mfrkHY.js";const p=e({__name:"express-modal",setup(s){return(n,r)=>(a(),o("div",null,"express-modal.vue"))}});export{p as default};
