import{a2 as e,ao as t,ay as a}from"../jse/index-index-N7mfrkHY.js";const r=e({__name:"customs-detail",setup(o){return(s,n)=>(t(),a("div",null,"customs-detail.vue"))}});export{r as default};
