import{a2 as e,ao as t,ay as a}from"../jse/index-index-N7mfrkHY.js";const l=e({__name:"count-detail",setup(n){return(o,c)=>(t(),a("div",null,"count-detail.vue"))}});export{l as default};
