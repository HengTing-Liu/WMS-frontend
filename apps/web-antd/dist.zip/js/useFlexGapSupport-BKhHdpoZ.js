import{aI as a}from"./bootstrap-BrzYYM59.js";import{ai as o,aC as t}from"../jse/index-index-N7mfrkHY.js";const s=(()=>{const e=t(!1);return o(()=>{e.value=a()}),e});export{s as u};
