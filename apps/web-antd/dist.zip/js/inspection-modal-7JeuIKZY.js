import{a2 as e,ao as n,ay as o}from"../jse/index-index-N7mfrkHY.js";const p=e({__name:"inspection-modal",setup(a){return(t,c)=>(n(),o("div",null,"inspection-modal.vue"))}});export{p as default};
