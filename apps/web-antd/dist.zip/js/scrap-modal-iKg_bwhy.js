import{a2 as a,ao as e,ay as o}from"../jse/index-index-N7mfrkHY.js";const s=a({__name:"scrap-modal",setup(n){return(r,t)=>(e(),o("div",null,"scrap-modal.vue"))}});export{s as default};
