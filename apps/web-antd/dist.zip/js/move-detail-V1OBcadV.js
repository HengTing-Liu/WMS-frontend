import{a2 as e,ao as a,ay as o}from"../jse/index-index-N7mfrkHY.js";const l=e({__name:"move-detail",setup(t){return(n,r)=>(a(),o("div",null,"move-detail.vue"))}});export{l as default};
